package com.replaymod.core;

import cpw.mods.fml.relauncher.CoreModManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Set;

import net.minecraft.launchwrapper.Launch;

import org.spongepowered.asm.lib.tree.ClassNode;

public class ReplayModMixinConfigPlugin implements IMixinConfigPlugin {
    static boolean hasClass(String name) throws IOException {
        return Launch.classLoader.getClassBytes(name) != null;
    }

    private static boolean hasClassResource(String name) {
        return Launch.classLoader.getResource(name.replace('.', '/') + ".class") != null;
    }

    private static boolean prepareMCHeli() throws IOException {
        final String className = "mcheli.MCH_ClientProxy";
        final String resourcePath = className.replace('.', '/') + ".class";

        // Avoid getClassBytes() here. LaunchClassLoader negatively caches misses,
        // which would keep a later-added folder mod invisible to Mixin.
        if (hasClassResource(className)) {
            return true;
        }

        File source = findFolderModContaining(resourcePath);
        if (source == null) {
            return false;
        }

        source = source.getCanonicalFile();
        URL sourceUrl = source.toURI().toURL();

        // Mixin prepares before normal FML mod discovery in 1.7.10. Put the
        // folder mod on LaunchWrapper's search path now so @Pseudo targets can
        // be resolved when the replay mixin configuration is prepared.
        Launch.classLoader.addURL(sourceUrl);

        // FML scans LaunchClassLoader sources first and mods/ second. Mark the
        // original folder name as already handled by the early scan so the same
        // directory is not discovered twice later. Directory classpath sources
        // are still examined by findClasspathMods(), even when their name is in
        // this list; findModDirMods() is the phase that skips the name.
        List<String> loadedCoremods = CoreModManager.getLoadedCoremods();
        if (!loadedCoremods.contains(source.getName())) {
            loadedCoremods.add(source.getName());
        }

        // If the source lives in mods/1.7.10/, also keep the parent directory
        // itself from being treated as a separate root-level directory mod.
        File parent = source.getParentFile();
        if (parent != null && "1.7.10".equals(parent.getName()) && !loadedCoremods.contains(parent.getName())) {
            loadedCoremods.add(parent.getName());
        }

        return hasClassResource(className);
    }

    private static File findFolderModContaining(String resourcePath) throws IOException {
        if (Launch.minecraftHome != null) {
            File source = findFolderModContaining(new File(Launch.minecraftHome, "mods"), resourcePath);
            if (source != null) {
                return source;
            }
        }

        File workingDirectory = new File(System.getProperty("user.dir", "."));
        if (Launch.minecraftHome == null || !sameFile(Launch.minecraftHome, workingDirectory)) {
            return findFolderModContaining(new File(workingDirectory, "mods"), resourcePath);
        }

        return null;
    }

    private static File findFolderModContaining(File modsDirectory, String resourcePath) {
        if (modsDirectory == null || !modsDirectory.isDirectory()) {
            return null;
        }

        File[] entries = modsDirectory.listFiles();
        if (entries == null) {
            return null;
        }

        for (File entry : entries) {
            if (!entry.isDirectory()) {
                continue;
            }

            if (new File(entry, resourcePath).isFile()) {
                return entry;
            }

            if ("1.7.10".equals(entry.getName())) {
                File nested = findFolderModContaining(entry, resourcePath);
                if (nested != null) {
                    return nested;
                }
            }
        }

        return null;
    }

    private static boolean sameFile(File first, File second) {
        try {
            return first.getCanonicalFile().equals(second.getCanonicalFile());
        } catch (IOException ignored) {
            return first.getAbsoluteFile().equals(second.getAbsoluteFile());
        }
    }

    private final Logger logger = LogManager.getLogger("replaymod/mixin");
    private final boolean hasOF = hasClass("optifine.OptiFineForgeTweaker");
    private final boolean hasMCHeli = prepareMCHeli();

    {
        logger.debug("hasOF: " + hasOF);
        logger.debug("hasMCHeli: " + hasMCHeli);
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        if (mixinClassName.endsWith("_OF")) return hasOF;
        if (mixinClassName.endsWith("_NoOF")) return !hasOF;
        if (mixinClassName.endsWith("_MCHeli")) return hasMCHeli;
        return true;
    }

    @Override
    public void onLoad(String mixinPackage) {
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {

    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }

    public ReplayModMixinConfigPlugin() throws IOException {
    }
}
