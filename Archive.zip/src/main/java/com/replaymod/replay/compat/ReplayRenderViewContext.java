package com.replaymod.replay.compat;

import com.replaymod.replay.ReplayHandler;
import com.replaymod.replay.ReplayModReplay;
import com.replaymod.replay.camera.CameraEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

import java.lang.reflect.Field;
import java.util.UUID;

/**
 * Replay-only compatibility context for mods which distinguish the local
 * client player from the recorded player being viewed.
 *
 * Minecraft.thePlayer must remain ReplayMod's CameraEntity for the lifetime of
 * replay playback. Recorded entities are read-only playback state and must
 * never become the live controlling player. Optional compatibility adapters
 * can use this class to borrow only visual identity or a scoped riding
 * relationship from the recorded spectated player.
 */
public final class ReplayRenderViewContext {
    private static final ThreadLocal<Integer> ENTITY_RENDER_DEPTH = new ThreadLocal<Integer>() {
        @Override
        protected Integer initialValue() {
            return 0;
        }
    };

    private static final ThreadLocal<MCHeliVisualTickState> MCHELI_VISUAL_TICK =
            new ThreadLocal<MCHeliVisualTickState>();
    private static final ThreadLocal<Integer> MCHELI_CLIENT_PLAYER_VISUAL_DEPTH =
            new ThreadLocal<Integer>() {
                @Override
                protected Integer initialValue() {
                    return 0;
                }
            };

    private static boolean fmurCompatibilityProbed;
    private static boolean fmurCompatibilityAvailable;
    private static boolean fmurThirdPersonOverrideApplied;
    private static boolean fmurOriginalDisableThirdPerson;
    private static Field fmurDisableThirdPersonField;
    private static Field fmurTeamsScoreGuiLockField;
    private static Field fmurHitMarkerField;

    private static boolean hitmarkerPlusProbed;
    private static boolean hitmarkerPlusAvailable;
    private static Field hitmarkerPlusLastTriggerMsField;
    private static Field hitmarkerPlusLastKillDistanceMsField;

    private ReplayRenderViewContext() {
    }

    public static void enterEntityRender() {
        ENTITY_RENDER_DEPTH.set(ENTITY_RENDER_DEPTH.get() + 1);
    }

    public static void exitEntityRender() {
        int depth = ENTITY_RENDER_DEPTH.get();
        if (depth <= 1) {
            ENTITY_RENDER_DEPTH.remove();
        } else {
            ENTITY_RENDER_DEPTH.set(depth - 1);
        }
    }

    public static boolean isEntityRendering() {
        return ENTITY_RENDER_DEPTH.get() > 0;
    }

    /**
     * @return whether ReplayMod currently owns Minecraft.thePlayer for replay
     *         playback.
     */
    public static boolean isReplayActive() {
        Minecraft mc = Minecraft.getMinecraft();
        return mc.thePlayer instanceof CameraEntity
                && ReplayModReplay.instance.getReplayHandler() != null;
    }

    /**
     * Resolve the recorded player selected by ReplayMod itself. This must be
     * based on ReplayHandler's spectated UUID, not renderViewEntity: MCHeli and
     * other vehicle mods may legitimately replace renderViewEntity with a
     * visual-only camera, while a stale renderViewEntity must never turn free
     * camera back into pseudo-spectating.
     *
     * @return the recorded player currently being spectated, or {@code null}
     */
    public static EntityPlayer getSpectatedPlayerForVisuals() {
        Minecraft mc = Minecraft.getMinecraft();
        if (!(mc.thePlayer instanceof CameraEntity)) {
            return null;
        }

        ReplayHandler handler = ReplayModReplay.instance.getReplayHandler();
        if (handler == null || mc.theWorld == null) {
            return null;
        }

        UUID spectated = handler.getSpectatedUUID();
        if (spectated == null) {
            return null;
        }

        EntityPlayer player = mc.theWorld.getPlayerEntityByUUID(spectated);
        return player != null && player != mc.thePlayer ? player : null;
    }

    /**
     * @return the recorded player currently being spectated, but only while an
     *         entity render is in progress; otherwise {@code null}
     */
    public static EntityPlayer getSpectatedPlayerForEntityRender() {
        if (!isEntityRendering()) {
            return null;
        }

        return getSpectatedPlayerForVisuals();
    }

    /**
     * MCHeli's tank camera anti-clip path asks its client proxy for the local
     * player from inside MCH_EntityTank#updateCamera. That is a visual camera
     * calculation, not a control/physics query, so expose the recorded player
     * only for the exact duration of that call.
     */
    public static void enterMCHeliClientPlayerVisualContext() {
        MCHELI_CLIENT_PLAYER_VISUAL_DEPTH.set(MCHELI_CLIENT_PLAYER_VISUAL_DEPTH.get() + 1);
    }

    public static void exitMCHeliClientPlayerVisualContext() {
        int depth = MCHELI_CLIENT_PLAYER_VISUAL_DEPTH.get();
        if (depth <= 1) {
            MCHELI_CLIENT_PLAYER_VISUAL_DEPTH.remove();
        } else {
            MCHELI_CLIENT_PLAYER_VISUAL_DEPTH.set(depth - 1);
        }
    }

    public static EntityPlayer getSpectatedPlayerForMCHeliClientVisuals() {
        if (!isEntityRendering() && MCHELI_CLIENT_PLAYER_VISUAL_DEPTH.get() <= 0) {
            return null;
        }
        return getSpectatedPlayerForVisuals();
    }

    /** True only for ReplayMod's independently positioned flying camera. */
    public static boolean isReplayFreeCamera() {
        return isReplayActive() && getSpectatedPlayerForVisuals() == null;
    }

    /**
     * Local-only feedback (hit markers, kill distance, etc.) belongs to the
     * recorded player's first-person view, never to free camera/F5.
     */
    public static boolean shouldRenderRecordedLocalFeedback() {
        if (!isReplayActive()) {
            return true;
        }
        Minecraft mc = Minecraft.getMinecraft();
        return getSpectatedPlayerForVisuals() != null
                && mc.gameSettings != null
                && mc.gameSettings.thirdPersonView == 0;
    }

    /**
     * During MCHeli's client visual tick/render tick, temporarily expose the
     * recorded player's ridingEntity through CameraEntity. This is a field-only
     * visual proxy: mountEntity is never invoked and the vehicle's
     * riddenByEntity/seat ownership is never changed.
     *
     * MCHeli 1.7.10 reads Entity.ridingEntity directly in both its normal tick
     * and onRenderTickPre camera-position path. Both paths therefore need the
     * same scoped proxy for cockpit offsets, seat transforms and vehicle roll.
     */
    public static void enterMCHeliVisualTick() {
        MCHeliVisualTickState state = MCHELI_VISUAL_TICK.get();
        if (state == null) {
            state = new MCHeliVisualTickState();
            MCHELI_VISUAL_TICK.set(state);
        }

        if (state.depth++ != 0) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();
        if (!(mc.thePlayer instanceof CameraEntity)) {
            return;
        }

        EntityPlayer spectated = getSpectatedPlayerForVisuals();
        if (spectated == null) {
            return;
        }

        CameraEntity camera = (CameraEntity) mc.thePlayer;
        state.camera = camera;
        state.originalRidingEntity = camera.ridingEntity;
        state.proxied = true;

        // CameraEntity is MCHeli's local-client surrogate during this tightly
        // scoped visual pass. Seed its view angles from the recorded player
        // before MCHeli applies the vehicle's normal seat/camera transforms.
        // Live mouse deltas are suppressed separately, so this cannot steer the
        // replayed aircraft.
        camera.prevRotationYaw = spectated.prevRotationYaw;
        camera.rotationYaw = spectated.rotationYaw;
        camera.prevRotationPitch = spectated.prevRotationPitch;
        camera.rotationPitch = spectated.rotationPitch;
        camera.rotationYawHead = spectated.rotationYawHead;
        camera.prevRotationYawHead = spectated.prevRotationYawHead;

        camera.ridingEntity = spectated.ridingEntity;
    }

    public static void exitMCHeliVisualTick() {
        MCHeliVisualTickState state = MCHELI_VISUAL_TICK.get();
        if (state == null) {
            return;
        }

        if (--state.depth > 0) {
            return;
        }

        if (state.proxied && state.camera != null) {
            state.camera.ridingEntity = state.originalRidingEntity;
        }
        MCHELI_VISUAL_TICK.remove();
    }

    /**
     * MCHeli's onRenderTickPre updates the recorded rider and seat render
     * positions, and may deliberately choose CameraEntity as its first-person
     * render view. In that case copy only the newly corrected position back to
     * CameraEntity. Do not replace its rotation here: MCHeli has just applied
     * its cockpit/seat orientation and camera roll.
     */
    public static void finishMCHeliRenderTick() {
        Minecraft mc = Minecraft.getMinecraft();
        if (!(mc.thePlayer instanceof CameraEntity) || mc.theWorld == null) {
            return;
        }

        EntityPlayer spectated = getSpectatedPlayerForVisuals();
        if (spectated == null || !isSpectatedPlayerInMCHeliVehicle(spectated)) {
            return;
        }

        // The recorded player's first-person vehicle view must use MCHeli's own
        // camera entity. setupAllRiderRenderPosition() writes the asset-defined
        // CameraPosition (including turret-relative offsets) into
        // MCH_ViewEntityDummy every render tick. Looking from CameraEntity or the
        // rider body instead is exactly what causes cockpit/tank-model clipping.
        if (mc.gameSettings != null && mc.gameSettings.thirdPersonView == 0) {
            EntityLivingBase nativeView = findMCHeliViewEntity(mc, "mcheli.MCH_ViewEntityDummy");
            if (nativeView != null) {
                mc.renderViewEntity = nativeView;
            }
        }
        // In F5, leave MCHeli's own MCH_3rdCamera selection untouched.
    }

    private static EntityLivingBase findMCHeliViewEntity(Minecraft mc, String className) {
        if (mc == null || mc.theWorld == null || className == null) {
            return null;
        }
        for (Object value : mc.theWorld.loadedEntityList) {
            if (value instanceof EntityLivingBase
                    && className.equals(value.getClass().getName())
                    && !((EntityLivingBase) value).isDead) {
                return (EntityLivingBase) value;
            }
        }
        return null;
    }

    /**
     * MCHeli seat/camera queries receive CameraEntity as their local player.
     * Map that identity back to the recorded spectated player only for those
     * visual queries.
     */
    public static Entity getSpectatedEntityForReplayCamera(Entity entity) {
        if (entity instanceof CameraEntity) {
            EntityPlayer spectated = getSpectatedPlayerForVisuals();
            if (spectated != null) {
                return spectated;
            }
        }
        return entity;
    }

    /**
     * MCHeli's normal camera path may install one of these visual-only entities
     * as Minecraft.renderViewEntity. ReplayMod should preserve that visual
     * camera while still tracking the selected recorded player by UUID.
     */
    public static boolean isMCHeliVisualCamera(Entity entity) {
        if (entity == null) {
            return false;
        }
        String name = entity.getClass().getName();
        return "mcheli.MCH_ViewEntityDummy".equals(name)
                || "mcheli.MCH_3rdCamera".equals(name);
    }

    /**
     * @return true when the recorded player is currently attached to an MCHeli
     *         aircraft, seat or UAV station. Uses class names only so ReplayMod
     *         retains no hard MCHeli compile dependency.
     */
    public static boolean isSpectatedPlayerInMCHeliVehicle(EntityPlayer player) {
        return player != null && isMCHeliVehicleEntity(player.ridingEntity);
    }

    private static boolean isMCHeliVehicleEntity(Entity entity) {
        if (entity == null) {
            return false;
        }

        for (Class<?> type = entity.getClass(); type != null; type = type.getSuperclass()) {
            String name = type.getName();
            if ("mcheli.aircraft.MCH_EntityAircraft".equals(name)
                    || "mcheli.aircraft.MCH_EntitySeat".equals(name)
                    || "mcheli.uav.MCH_EntityUavStation".equals(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * MCHeli's vehicle HUD and hit/damage messages represent the recorded
     * player's cockpit. Show them only when the viewer is actually spectating a
     * recorded player in first person. Free camera and F5 views remain clean.
     */
    public static boolean shouldRenderMCHeliReplayHud() {
        return shouldRenderRecordedLocalFeedback();
    }

    /**
     * Replay playback must not open modal gameplay/team/admin screens merely
     * because their historical network packets are being replayed. Keep the
     * filter intentionally narrow to known gameplay GUI packages so vanilla,
     * ReplayMod, JourneyMap and other user-invoked screens remain unaffected.
     */
    public static boolean shouldSuppressExternalReplayGui(GuiScreen screen) {
        if (!isReplayActive() || screen == null) {
            return false;
        }

        String name = screen.getClass().getName();
        return "com.flansmod.client.gui.GuiTeamScores".equals(name)
                || "com.flansmod.client.gui.GuiTeamSelect".equals(name)
                || "com.flansmod.client.gui.GuiDriveableController".equals(name)
                || "com.flansmod.client.gui.GuiSelectAmmo".equals(name)
                || "com.wdg.wgevents.client.GuiVoting".equals(name)
                || "com.wdg.wgevents.client.GuiCaptureAdmin".equals(name)
                || "com.wdg.wgevents.client.GuiWGEAdmin".equals(name)
                || "com.wdg.wgevents.client.GuiWallet".equals(name)
                || "com.wdg.wgevents.client.GuiShop".equals(name)
                || "com.wdg.wgevents.client.GuiShopAdmin".equals(name)
                || "com.wdg.wgevents.client.GuiPlayerMenu".equals(name);
    }

    /**
     * FMUR intentionally disables infantry F5 in live gameplay. CameraEntity is
     * deliberately never mounted, so that rule would incorrectly classify the
     * replay viewer as infantry. Temporarily disable only that client rule for
     * replay lifetime, and clear replayed transient team/hit-marker state that
     * otherwise belongs to the historical local client rather than the viewer.
     *
     * Reflection keeps FMUR optional and avoids a hard classpath dependency.
     */
    public static void maintainReplayClientCompatibilityState() {
        if (!isReplayActive()) {
            return;
        }

        maintainHitmarkerPlusReplayState();
        probeFMURCompatibility();
        if (!fmurCompatibilityAvailable) {
            return;
        }

        try {
            if (!fmurThirdPersonOverrideApplied) {
                fmurOriginalDisableThirdPerson = fmurDisableThirdPersonField.getBoolean(null);
                fmurThirdPersonOverrideApplied = true;
            }
            fmurDisableThirdPersonField.setBoolean(null, false);

            // Historical round-end packets must not continually reopen Teams.
            if (fmurTeamsScoreGuiLockField != null) {
                fmurTeamsScoreGuiLockField.setInt(null, 0);
            }

            // A replayed hit marker is meaningful only in the recorded player's
            // first-person view. Clear it in free camera/F5 views.
            if (!shouldRenderMCHeliReplayHud() && fmurHitMarkerField != null) {
                fmurHitMarkerField.setBoolean(null, false);
            }
        } catch (IllegalAccessException ignored) {
            fmurCompatibilityAvailable = false;
        }
    }

    /** Restore FMUR's live-game F5 policy when ReplayMod releases CameraEntity. */
    public static void releaseReplayClientCompatibilityState() {
        if (fmurThirdPersonOverrideApplied && fmurDisableThirdPersonField != null) {
            try {
                fmurDisableThirdPersonField.setBoolean(null, fmurOriginalDisableThirdPerson);
            } catch (IllegalAccessException ignored) {
                // The replay is already closing; do not make teardown fragile.
            }
        }
        fmurThirdPersonOverrideApplied = false;
    }

    /**
     * HitmarkerPlus draws from private static timestamps during Post/ALL. Its
     * packet-trigger mixin is kept as an early filter when available, but the
     * mod may not yet be on LaunchWrapper's class path when ReplayMod's mixin
     * config is prepared. Clear the render timestamps every replay frame while
     * not in recorded-player first person so detached/F5 views cannot inherit a
     * marker that was triggered by historical local-client packets.
     */
    private static void maintainHitmarkerPlusReplayState() {
        if (shouldRenderRecordedLocalFeedback()) {
            return;
        }
        probeHitmarkerPlusCompatibility();
        if (!hitmarkerPlusAvailable) {
            return;
        }
        try {
            hitmarkerPlusLastTriggerMsField.setLong(null, 0L);
            hitmarkerPlusLastKillDistanceMsField.setLong(null, 0L);
        } catch (IllegalAccessException ignored) {
            hitmarkerPlusAvailable = false;
        }
    }

    private static void probeHitmarkerPlusCompatibility() {
        if (hitmarkerPlusProbed) {
            return;
        }
        hitmarkerPlusProbed = true;
        try {
            Class<?> overlay = Class.forName("com.hitmarkerplus.client.HitmarkerOverlay", false,
                    ReplayRenderViewContext.class.getClassLoader());
            hitmarkerPlusLastTriggerMsField = overlay.getDeclaredField("lastTriggerMs");
            hitmarkerPlusLastKillDistanceMsField = overlay.getDeclaredField("lastKillDistanceMs");
            hitmarkerPlusLastTriggerMsField.setAccessible(true);
            hitmarkerPlusLastKillDistanceMsField.setAccessible(true);
            hitmarkerPlusAvailable = true;
        } catch (ClassNotFoundException ignored) {
            hitmarkerPlusAvailable = false;
        } catch (NoSuchFieldException ignored) {
            hitmarkerPlusAvailable = false;
        } catch (LinkageError ignored) {
            hitmarkerPlusAvailable = false;
        } catch (SecurityException ignored) {
            hitmarkerPlusAvailable = false;
        }
    }

    private static void probeFMURCompatibility() {
        if (fmurCompatibilityProbed) {
            return;
        }
        fmurCompatibilityProbed = true;

        try {
            Class<?> client = Class.forName("com.flansmod.client.FlansModClient", false,
                    ReplayRenderViewContext.class.getClassLoader());
            fmurDisableThirdPersonField = client.getField("disableThirdPerson");
            fmurTeamsScoreGuiLockField = findPublicField(client, "teamsScoreGUILock");
            fmurHitMarkerField = findPublicField(client, "hitMarker");
            fmurCompatibilityAvailable = true;
        } catch (ClassNotFoundException ignored) {
            fmurCompatibilityAvailable = false;
        } catch (NoSuchFieldException ignored) {
            fmurCompatibilityAvailable = false;
        } catch (LinkageError ignored) {
            fmurCompatibilityAvailable = false;
        }
    }

    private static Field findPublicField(Class<?> owner, String name) {
        try {
            return owner.getField(name);
        } catch (NoSuchFieldException ignored) {
            return null;
        }
    }

    private static final class MCHeliVisualTickState {
        int depth;
        boolean proxied;
        CameraEntity camera;
        Entity originalRidingEntity;
    }
}
