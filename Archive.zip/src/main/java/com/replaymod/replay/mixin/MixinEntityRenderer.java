package com.replaymod.replay.mixin;

import com.replaymod.replay.camera.CameraEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {
    @Shadow private float prevCamRoll;
    @Shadow private float camRoll;
    @Shadow private Minecraft mc;

    @Inject(method = "orientCamera", at = @At("HEAD"))
    private void applyRoll(float partialTicks, CallbackInfo ci) {
        EntityLivingBase view = mc.renderViewEntity;
        if (view instanceof CameraEntity) {
            prevCamRoll = camRoll = ((CameraEntity) view).roll;
        }
    }

    /**
     * MCHeli camera-mode teardown can remove CameraEntity's short-lived night
     * vision effect between vanilla's outer potion-active check and this helper.
     * Vanilla 1.7.10 blindly dereferences the effect here. Treat the transitional
     * state as zero brightness instead of crashing while the replay world closes.
     */
    @Inject(method = "getNightVisionBrightness", at = @At("HEAD"), cancellable = true)
    private void replayModCompat$guardCameraNightVisionBrightness(
            EntityPlayer player, float partialTicks, CallbackInfoReturnable<Float> cir) {
        if (player instanceof CameraEntity && player.getActivePotionEffect(Potion.nightVision) == null) {
            cir.setReturnValue(0.0F);
        }
    }
}
