package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replay-safe local camera feedback for FMUR. */
@Pseudo
@Mixin(targets = "com.flansmod.client.TickHandlerClient", remap = false)
public abstract class MixinFMURReplayFeedback {
    /** Shot recoil/shake belongs to the live shooter and has no spatial origin. */
    @Inject(method = "triggerShotScreenShake", at = @At("HEAD"), cancellable = true, remap = false)
    private static void replayModCompat$dropRecordedShotShake(float degrees, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }

    /**
     * Explosion shake is useful while filming, but only in true free camera.
     * FMUR has already calculated the degree value from Minecraft.thePlayer; in
     * free camera that is CameraEntity, so its normal distance falloff remains
     * spatially correct. Following a recorded player/vehicle stays shake-free.
     */
    @Inject(method = "triggerExplosionScreenShake(F)V", at = @At("HEAD"), cancellable = true, remap = false)
    private static void replayModCompat$spatializeReplayExplosionShake(float degrees, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive() && !ReplayRenderViewContext.isReplayFreeCamera()) {
            ci.cancel();
        }
    }
}
