package com.replaymod.replay.mixin;

import com.replaymod.replay.ReplayModReplay;
import com.replaymod.replay.Setting;
import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.client.gui.GuiNewChat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Makes the Show Chat replay setting apply immediately to already-buffered lines. */
@Mixin(GuiNewChat.class)
public abstract class MixinGuiNewChatReplayVisibility {
    @Inject(method = "drawChat", at = @At("HEAD"), cancellable = true)
    private void replayModCompat$hideReplayChatImmediately(int updateCounter, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()
                && !ReplayModReplay.instance.getCore().getSettingsRegistry().get(Setting.SHOW_CHAT)) {
            ci.cancel();
        }
    }
}
