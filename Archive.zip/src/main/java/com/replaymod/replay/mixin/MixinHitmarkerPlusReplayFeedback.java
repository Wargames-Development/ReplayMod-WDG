package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps HitmarkerPlus local feedback attached to recorded first-person only. */
@Pseudo
@Mixin(targets = "com.hitmarkerplus.client.ClientHitmarker", remap = false)
public abstract class MixinHitmarkerPlusReplayFeedback {
    @Inject(method = "trigger", at = @At("HEAD"), cancellable = true, remap = false)
    private static void replayModCompat$filterReplayHitmarker(
            boolean showHitmarker, boolean headshot, int killDistanceBlocks, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()
                && !ReplayRenderViewContext.shouldRenderRecordedLocalFeedback()) {
            ci.cancel();
        }
    }
}
