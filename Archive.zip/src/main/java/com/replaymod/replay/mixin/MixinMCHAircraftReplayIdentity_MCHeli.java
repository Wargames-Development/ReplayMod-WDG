package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Makes MCHeli's seat/camera identity queries treat ReplayMod's CameraEntity as
 * the recorded spectated player, without changing the actual rider entities.
 */
@Pseudo
@Mixin(targets = "mcheli.aircraft.MCH_EntityAircraft", remap = false)
public abstract class MixinMCHAircraftReplayIdentity_MCHeli {
    @ModifyVariable(
            method = "getSeatIdByEntity",
            at = @At("HEAD"),
            argsOnly = true,
            remap = false
    )
    private Entity replayModCompat$mapSeatIdentity(Entity entity) {
        return ReplayRenderViewContext.getSpectatedEntityForReplayCamera(entity);
    }

    @ModifyVariable(
            method = "getAircraft_RiddenOrControl",
            at = @At("HEAD"),
            argsOnly = true,
            remap = false
    )
    private static Entity replayModCompat$mapRiderIdentity(Entity entity) {
        return ReplayRenderViewContext.getSpectatedEntityForReplayCamera(entity);
    }
}
