package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevent MCHeli's render-stage live mouse solver from mutating replay aircraft/player state. */
@Pseudo
@Mixin(targets = "mcheli.aircraft.MCH_EntityAircraft", remap = false)
public abstract class MixinMCHAircraftReplayPassivity_MCHeli {
    @Inject(method = "setAngles", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$cancelReplaySetAngles(
            Entity player, boolean fixRot, float fixYaw, float fixPitch,
            float deltaX, float deltaY, float x, float y, float partialTicks, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }
}
