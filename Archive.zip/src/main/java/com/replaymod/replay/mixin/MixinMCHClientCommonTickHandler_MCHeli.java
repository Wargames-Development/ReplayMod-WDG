package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replay-safe bridge for MCHeli's common client tick, render camera path and
 * HUD dispatcher.
 *
 * ReplayMod keeps Minecraft.thePlayer as CameraEntity. MCHeli nevertheless
 * needs to observe the recorded player's riding relationship while executing
 * its visual-only camera/seat calculations. The proxy is scoped to MCHeli's
 * own tick/render methods and never creates a real mount relationship.
 */
@Pseudo
@Mixin(targets = "mcheli.MCH_ClientCommonTickHandler", remap = false)
public abstract class MixinMCHClientCommonTickHandler_MCHeli {
    @Shadow(remap = false) private static double prevMouseDeltaX;
    @Shadow(remap = false) private static double prevMouseDeltaY;
    @Shadow(remap = false) private static double mouseDeltaX;
    @Shadow(remap = false) private static double mouseDeltaY;
    @Shadow(remap = false) private static double mouseRollDeltaX;
    @Shadow(remap = false) private static double mouseRollDeltaY;

    @Inject(method = "onTick", at = @At("HEAD"), remap = false)
    private void replayModCompat$enterVisualVehicleContext(CallbackInfo ci) {
        ReplayRenderViewContext.enterMCHeliVisualTick();
    }

    @Inject(method = "onTick", at = @At("RETURN"), remap = false)
    private void replayModCompat$exitVisualVehicleContext(CallbackInfo ci) {
        ReplayRenderViewContext.exitMCHeliVisualTick();
    }

    /**
     * MCHeli performs the actual seat transforms, configured camera-position
     * placement and aircraft-roll calculation in onRenderTickPre rather than
     * onTick. Give that render-only path the same recorded riding identity.
     */
    @Inject(method = "onRenderTickPre", at = @At("HEAD"), remap = false)
    private void replayModCompat$enterRenderVehicleContext(float partialTicks, CallbackInfo ci) {
        ReplayRenderViewContext.enterMCHeliVisualTick();
    }

    @Inject(method = "onRenderTickPre", at = @At("RETURN"), remap = false)
    private void replayModCompat$exitRenderVehicleContext(float partialTicks, CallbackInfo ci) {
        ReplayRenderViewContext.finishMCHeliRenderTick();
        ReplayRenderViewContext.exitMCHeliVisualTick();
    }

    /**
     * MCHeli's render camera routine also consumes live mouse deltas and can
     * feed them back into aircraft/player rotation. Replays are visual-only:
     * clear the complete MCHeli mouse state and leave recorded motion untouched.
     */
    @Inject(method = "updateMouseDelta", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$freezeReplayMouseDelta(boolean stickMode, float partialTicks, CallbackInfo ci) {
        if (!ReplayRenderViewContext.isReplayActive()) {
            return;
        }

        prevMouseDeltaX = 0.0D;
        prevMouseDeltaY = 0.0D;
        mouseDeltaX = 0.0D;
        mouseDeltaY = 0.0D;
        mouseRollDeltaX = 0.0D;
        mouseRollDeltaY = 0.0D;
        ci.cancel();
    }

    /**
     * MCHeli's local damage totals / hit messages are rendered from the HOTBAR
     * phase. Keep normal vehicle HUD/crosshair behavior in F5, but never leak
     * those local-only hit indicators into free camera or third person.
     */
    @Inject(method = "onRenderGameOverlayEvent", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$hideLocalHitHudOutsideRecordedFirstPerson(
            RenderGameOverlayEvent event, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()
                && event.type == RenderGameOverlayEvent.ElementType.HOTBAR
                && !ReplayRenderViewContext.shouldRenderMCHeliReplayHud()) {
            ci.cancel();
        }
    }

    @ModifyArg(
            method = "drawGui(Lmcheli/gui/MCH_Gui;F)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lmcheli/gui/MCH_Gui;isDrawGui(Lnet/minecraft/entity/player/EntityPlayer;)Z"
            ),
            index = 0,
            remap = false
    )
    private EntityPlayer replayModCompat$useSpectatedPlayerForHudEligibility(EntityPlayer originalPlayer) {
        EntityPlayer spectated = ReplayRenderViewContext.getSpectatedPlayerForVisuals();
        return spectated != null ? spectated : originalPlayer;
    }
}
