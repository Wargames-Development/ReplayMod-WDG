package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * MCHeli-R asks its client proxy for the "client player" while rendering
 * aircraft, seats and first-person-sensitive parts.  In a replay that accessor
 * normally returns ReplayMod's CameraEntity, so the recorded pilot/passenger is
 * treated as a remote player and first-person model decisions are wrong.
 *
 * Substitute the recorded player only inside RenderManager's entity-render
 * scope or MCHeli's explicitly scoped visual camera calculation. Outside those
 * contexts MCHeli keeps seeing CameraEntity, preventing replayed players from
 * entering live control/physics branches.
 */
@Pseudo
@Mixin(targets = "mcheli.MCH_ClientProxy", remap = false)
public abstract class MixinMCHClientProxy_MCHeli {
    @Inject(
            method = "getClientPlayer",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private void replayModCompat$useSpectatedPlayerForRendering(CallbackInfoReturnable<Entity> cir) {
        EntityPlayer spectated = ReplayRenderViewContext.getSpectatedPlayerForMCHeliClientVisuals();
        if (spectated != null) {
            cir.setReturnValue(spectated);
        }
    }
}
