package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevent replay-viewer input from operating an MCHeli GLTD. */
@Pseudo
@Mixin(targets = "mcheli.gltd.MCH_ClientGLTDTickHandler", remap = false)
public abstract class MixinMCHGLTDTickHandler_MCHeli {
    @Inject(method = "playerControl", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$cancelLiveReplayGltdControl(CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }
}
