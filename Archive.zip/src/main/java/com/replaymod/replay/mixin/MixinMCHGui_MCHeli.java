package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Makes MCHeli HUD drawing use the recorded player currently being viewed.
 *
 * MCH_Gui#drawScreen (SRG func_73863_a) normally forwards Minecraft.thePlayer to every concrete
 * MCHeli HUD.  During replay spectating that is ReplayMod's CameraEntity, so
 * helicopter/plane/tank/vehicle HUDs fail their ridden-aircraft and seat checks
 * even though Minecraft.renderViewEntity is the recorded pilot/passenger.
 *
 * Only the EntityPlayer argument passed into drawGui is replaced.  The real
 * Minecraft.thePlayer is left untouched, so MCHeli input, control and physics
 * code continues to see ReplayMod's CameraEntity rather than treating the
 * recorded player as a live controller.
 */
@Pseudo
@Mixin(targets = "mcheli.gui.MCH_Gui", remap = false)
public abstract class MixinMCHGui_MCHeli {
    @ModifyArg(
            method = "func_73863_a(IIF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lmcheli/gui/MCH_Gui;drawGui(Lnet/minecraft/entity/player/EntityPlayer;Z)V"
            ),
            index = 0,
            remap = false
    )
    private EntityPlayer replayModCompat$useSpectatedPlayerForHudDraw(EntityPlayer originalPlayer) {
        EntityPlayer spectated = ReplayRenderViewContext.getSpectatedPlayerForVisuals();
        return spectated != null ? spectated : originalPlayer;
    }
}
