package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevent replay-viewer input from firing or mode-switching MCHeli light weapons. */
@Pseudo
@Mixin(targets = "mcheli.lweapon.MCH_ClientLightWeaponTickHandler", remap = false)
public abstract class MixinMCHLightWeaponTickHandler_MCHeli {
    @Inject(method = "playerControl", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$cancelLiveReplayLightWeaponControl(CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }
}
