package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevent replay-viewer input from ejecting/parachuting/switching MCHeli seats. */
@Pseudo
@Mixin(targets = "mcheli.aircraft.MCH_ClientSeatTickHandler", remap = false)
public abstract class MixinMCHSeatTickHandler_MCHeli {
    @Inject(method = {"playerControl", "playerControlInGUI"}, at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$cancelLiveReplaySeatControl(CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }
}
