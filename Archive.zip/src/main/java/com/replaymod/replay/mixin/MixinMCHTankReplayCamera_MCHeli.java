package com.replaymod.replay.mixin;

import com.replaymod.replay.camera.CameraEntity;
import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Restores MCHeli tank camera anti-clipping without making CameraEntity a rider. */
@Pseudo
@Mixin(targets = "mcheli.tank.MCH_EntityTank", remap = false)
public abstract class MixinMCHTankReplayCamera_MCHeli {
    @Inject(method = "updateCamera", at = @At("HEAD"), remap = false)
    private void replayModCompat$enterTankCameraCalculation(double x, double y, double z, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ReplayRenderViewContext.enterMCHeliClientPlayerVisualContext();
        }
    }

    @Inject(method = "updateCamera", at = @At("RETURN"), remap = false)
    private void replayModCompat$exitTankCameraCalculation(double x, double y, double z, CallbackInfo ci) {
        ReplayRenderViewContext.exitMCHeliClientPlayerVisualContext();
    }

    /** Tank entry normally rewrites the local player's yaw/pitch; never mutate the replay camera. */
    @Inject(method = "onInteractFirst", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$skipReplayCameraEntryMutation(EntityPlayer player, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive() && player instanceof CameraEntity) {
            ci.cancel();
        }
    }

    /** Tank overrides the base aircraft angle solver, so cancel its replay copy separately. */
    @Inject(method = "setAngles", at = @At("HEAD"), cancellable = true, remap = false)
    private void replayModCompat$cancelReplayTankSetAngles(
            Entity player, boolean fixRot, float fixYaw, float fixPitch,
            float deltaX, float deltaY, float x, float y, float partialTicks, CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }
}
