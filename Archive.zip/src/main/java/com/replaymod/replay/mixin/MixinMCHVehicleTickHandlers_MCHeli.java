package com.replaymod.replay.mixin;

import com.replaymod.replay.compat.ReplayRenderViewContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Recorded MCHeli aircraft are playback state, never live controllable objects.
 * Keep each handler's normal update/camera/render path, but stop the direct
 * keyboard/mouse playerControl paths before they can mutate vehicle state or
 * send a new control packet from the replay viewer.
 */
@Pseudo
@Mixin(targets = {
        "mcheli.helicopter.MCH_ClientHeliTickHandler",
        "mcheli.plane.MCP_ClientPlaneTickHandler",
        "mcheli.tank.MCH_ClientTankTickHandler",
        "mcheli.vehicle.MCH_ClientVehicleTickHandler"
}, remap = false)
public abstract class MixinMCHVehicleTickHandlers_MCHeli {
    @Inject(
            method = {"playerControl", "playerControlInGUI"},
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private void replayModCompat$cancelLiveReplayControl(CallbackInfo ci) {
        if (ReplayRenderViewContext.isReplayActive()) {
            ci.cancel();
        }
    }
}
