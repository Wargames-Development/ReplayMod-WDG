package com.replaymod.replay.mixin;

import com.replaymod.replay.ReplayHandler;
import com.replaymod.replay.ReplayModReplay;
import com.replaymod.replay.compat.ReplayRenderViewContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replay playback is passive. Historical gameplay packets must not open
 * interactive external screens, and the normal chat screen must not steal the
 * T/command keys which ReplayMod uses to release the mouse for its overlay.
 */
@Mixin(Minecraft.class)
public abstract class MixinMinecraftReplayGuiIsolation {
    @Inject(method = "displayGuiScreen", at = @At("HEAD"), cancellable = true)
    private void replayModCompat$suppressHistoricalGameplayGui(GuiScreen screen, CallbackInfo ci) {
        ReplayHandler handler = ReplayModReplay.instance.getReplayHandler();

        // Minecraft 1.7.10 opens chat from runTick via KeyBinding.isPressed(),
        // not from dispatchKeypresses(). Even if another mod or a stale
        // pressTime reaches displayGuiScreen, ReplayMod owns T/command while a
        // replay is active: reveal the overlay mouse and never open GuiChat.
        if (handler != null && screen instanceof GuiChat) {
            handler.getOverlay().setMouseVisible(true);
            ci.cancel();
            return;
        }

        if (ReplayRenderViewContext.shouldSuppressExternalReplayGui(screen)) {
            ci.cancel();
        }
    }
}
