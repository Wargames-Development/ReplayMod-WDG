package com.replaymod.replay.mixin;

import com.replaymod.replay.ReplayHandler;
import com.replaymod.replay.ReplayModReplay;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Claims the physical chat/command bindings at Minecraft 1.7.10's real
 * KeyBinding.onTick boundary while replay playback is active.
 *
 * This prevents both vanilla GuiChat and mods sharing T (notably FMUR) from
 * receiving a pressTime increment, while using the key to release ReplayMod's
 * overlay mouse instead.
 */
@Mixin(KeyBinding.class)
public abstract class MixinReplayChatKeyBinding {
    @Inject(method = "onTick", at = @At("HEAD"), cancellable = true)
    private static void replayModCompat$claimReplayChatKey(int keyCode, CallbackInfo ci) {
        ReplayHandler handler = ReplayModReplay.instance.getReplayHandler();
        if (handler == null) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();
        GameSettings settings = mc.gameSettings;
        if (settings == null) {
            return;
        }

        if (keyCode == settings.keyBindChat.getKeyCode()
                || keyCode == settings.keyBindCommand.getKeyCode()) {
            handler.getOverlay().setMouseVisible(true);
            ci.cancel();
        }
    }
}
